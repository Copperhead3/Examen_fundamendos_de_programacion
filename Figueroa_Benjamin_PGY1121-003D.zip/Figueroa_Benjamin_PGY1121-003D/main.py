import csv
import random
import os
os.system("cls")

def asignar_sueldos(sueldos):
    for i in range(0,9):
        sueldos[i]=random.randint(300000,2500000)
    if sueldos is not None:
        print("Sueldos asignados correctamente\n")
        print(sueldos)
        

    return sueldos

def clasificar_sueldos(trabajadores,sueldos):
    for i in range(0,9):
        if sueldos[i]<800000:
            print("Nombre empleado    Sueldo")
            print(trabajadores[i],sueldos[i])
    return 
def menu():
    print("Menu:")
    print("1.Asignar sueldos aleatorios")
    print("2.Clasificar sueldos")
    print("3.Ver estadisticas")
    print("4.Reporte de sueldos")
    print("5.Salir del programa")
def estadisticas(sueldos):
    max_list={}
    for i in range(0,9):
        max_list=sueldos[i]
    print(max_list)

    #print(sorted(max_valor))
    #print(f"El sueldo mas alto es {max_sueldo[-1]}")
def main():

    sueldos={}
    trabajadores={"Juan Perez","Maria Garcia Lopez","Carlos Lopez","Ana Martinez",
                  "Pedro Rodriguez","Laura Hernandez","Miguel Sanchez","Isabel Gomez",
                  "Francisco Diaz","Elena Fernandez"}

  
    while True:
        menu()
        choice=input("Eleccion: ")
        os.system("cls")
        match choice:
            case '1':
                asignar_sueldos(sueldos)
            case '2':
                clasificar_sueldos(trabajadores,sueldos)
            case '3':
                estadisticas(sueldos)
            case '5':
                print("Desarrollado por Benjamin Figueroa\nRUT 21.457.292-3")
                break
            case _:
                return main()
    return
main()